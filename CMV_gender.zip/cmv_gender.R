##### STAN code for CMV transmission model #####
# Instead of solving lambda explicitly, we will estimate lambda and then give a penalty for inconsistancy

setwd("C:/Users/sophi/OneDrive/Documenten/VU master/RIVM/CMV model")
library(rstan)
library(readr)
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

### Import CMV data: Titers, Sexes, Ages ###
cmvdata <- read_csv("cmvdatanew.csv")

# filter non-dutch subjects
cmvdata = cmvdata[cmvdata$etnic == '1',]
Ages = cmvdata$LFTB
Titers = cmvdata$boxcoxvalues
N = length(Ages)

### Deal with censoring and spike ###
RightCensor = 3.41
Spike = -2.91
Censor = rep(0,N)
for (i in 1:N){
  if (Titers[i] > RightCensor){
    Censor[i] = 1
  }
  else if (Titers[i] <= Spike){
    Censor[i] = 2
  }
}

Titers_0 = Titers[cmvdata$LFTB == '0']
S0 = sum(Titers_0 < -0.8)/length(Titers_0)


### Distinguish gender ###
Gender= rep(0,N)
Gender[cmvdata$gesl2 == 'male'] = 1 # female = 0


### Import Contact Matrix ###
ContactData = read_csv("contact_intensities_aggregated.csv")

MM = ContactData$mMM # length 256 = 16*16
FM = ContactData$mFM
MF = ContactData$mMF
FF = ContactData$mFF

Contact_MM = matrix(MM,nrow=16,ncol=16)
Contact_FM = matrix(FM,nrow=16,ncol=16)
Contact_MF = matrix(MF,nrow=16,ncol=16)
Contact_FF = matrix(FF,nrow=16,ncol=16)


# some values
DeltaA = 5
A = 16
A_rho = 3
RhoClasses = c(1,1,1,1,2,2,2,2,2,2,3,3,3,3,3,3)


### Prepare a data dictionary an initial values for Stan ###

DataDict = list('N'= N,'A'= A,'A_rho'= A_rho,'DeltaA'= DeltaA,'Titers'= Titers,'Ages'= Ages,
                'Censor'= Censor,'RhoClasses'= RhoClasses,'RightCensor'= RightCensor,
                'Contact_MM'= Contact_MM,'Contact_FM'= Contact_FM,'Contact_MF'= Contact_MF,
                'Contact_FF'= Contact_FF,'MuS'= -1.68,'MuL'= 1.03,'MuB'= 2.6,'SigmaS'= 1/6.27,
                'SigmaL'= 1/1.52,'SigmaB'= 1/2.03,'Penalty'= 1e4,'S0'= S0,'Gender'= Gender)

initials = function(){
  return(list(beta1=0.0015,beta2=0.052,z=0.33,rho_f=c(0.015,0.03,0.042),rho_m=c(0.015,0.03,0.042),
              lambda_f=rep(0.01,A),lambda_m=rep(0.01,A),muRho=0.03,sigmaRho=0.02))
}


### Run the Stan model ###
out_gender3 = stan(file = 'cmv_def_gender.stan', data = DataDict, init = initials, iter = 2500, chains = 4,
             control = list(adapt_delta = 0.99))

library("shinystan")
shiny = launch_shinystan(out_gender)








